package Ocsinventory::Agent::Backend::OS::Generic::Repository;
use strict;

sub run {}

1;
